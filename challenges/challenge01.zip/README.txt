All challenge files will be at /challenges/challengeNumber.
The password for challenge X is the resulting string from challenge X-1.
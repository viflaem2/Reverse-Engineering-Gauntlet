#include <iostream>
#include <string>

using namespace std;

string encrypt1(const string &input) {
    string encrypted = input;
    for (char &c : encrypted) {
        c += c; 
        c -= 69;
    }
    return encrypted + "_Encrypted"; 
}

string encrypt2(const string &input) {
    string encrypted = input;
    for (int i = encrypted.length() - 1; i >= 0; --i) {
        encrypted[i] += 3;
        encrypted[i] += 2;
        encrypted[i] += 23;
        encrypted[i] += 1;
        encrypted[i] += -12;
        encrypted[i] += -9;
        encrypted[i] += 1;
        encrypted[i] += -8;
        encrypted[i] += -5;
        encrypted[i] += 6;
    }
    return encrypted; 
}

int main() {
    string secret = "???"; 
    string encryptedSecret = encrypt1(secret);
    string ultraEncryptedSecret = encrypt1(encrypt2(encryptedSecret)); 
    for (size_t i = 0; i < ultraEncryptedSecret.length(); i++) {
        cout << static_cast<int>(ultraEncryptedSecret[i]);
        if (i < ultraEncryptedSecret.length() - 1) 
            cout << ","; 
    }
    //117,53,1,1,17,-11,-3,-59,-71,125,1,13,1,-3,1,-55,125,73,-101,-123,-93,-79,-97,-89,-119,-121,95,69,110,99,114,121,112,116,101,100
    return 0;
}


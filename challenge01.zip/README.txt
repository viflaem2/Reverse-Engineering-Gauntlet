All challenge files will be at /challenges/challengeNumber.zip
The password for challenge X is the resulting string from challenge X-1
All challenge files will be at /challengeNumber.zip
The password for challenge X is the resulting string from challenge X-1